Práctica 1 AEDA
Modificación:
[1]Comprobar que se realizan todas las operaciones y testeo de fallos:
-Numeros menores que la base
-Si numero mayor o no valido, indicar que no es valido.
-Funcionamiento correcto cada una de las bases: 2,8,10,16...
[2]Método factorial a partir de un numero.

La clase calculator lee los operadores como si fueran un char, por lo que si se incluyen operadores que sea una cadena se tendría que modificar la clase calculator.
